/* atm_suni.h - Driver-specific declarations of the SUNI driver (for use by
		driver-specific utilities) */

/* Written 1998,2000 by Werner Almesberger, EPFL ICA */


#ifndef LINUX_ATM_SUNI_H
#define LINUX_ATM_SUNI_H

/* everything obsoleted */

#endif
